package com.lorenzocell.lcleaner

import android.content.Context
import android.os.storage.StorageManager
import android.text.format.DateFormat
import android.text.format.Formatter
import java.io.File
import java.io.FileOutputStream

object Cleaner {
    private const val MARGIN = 128L * 1024 * 1024

    data class Scan(val own: Long, val system: Long) { val total get() = own + system }

    private fun size(f: File): Long =
        if (f.isFile) f.length() else f.listFiles()?.sumOf { size(it) } ?: 0L

    private fun ownDirs(c: Context) = listOf(c.cacheDir) + c.externalCacheDirs.filterNotNull()

    /** Cache do próprio app + estimativa do cache que o sistema pode recuperar de outros apps. */
    fun scan(c: Context): Scan {
        val own = ownDirs(c).sumOf { size(it) }
        val sm = c.getSystemService(StorageManager::class.java)
        val reclaimable = try {
            sm.getAllocatableBytes(StorageManager.UUID_DEFAULT) - c.cacheDir.usableSpace
        } catch (e: Exception) { 0L }
        return Scan(own, (reclaimable - own).coerceAtLeast(0L))
    }

    /** Limpa o cache próprio e pede ao sistema para liberar o cache de outros apps. Retorna bytes liberados. */
    fun clean(c: Context): Long {
        val before = scan(c).total
        ownDirs(c).forEach { d -> d.listFiles()?.forEach { it.deleteRecursively() } }
        val tmp = File(c.cacheDir, "lc_reclaim.tmp")
        try {
            val sm = c.getSystemService(StorageManager::class.java)
            val target = sm.getAllocatableBytes(StorageManager.UUID_DEFAULT) - MARGIN
            if (target > c.cacheDir.usableSpace) {
                FileOutputStream(tmp).use { sm.allocateBytes(it.fd, target) }
            }
        } catch (e: Exception) {
            // Alguns aparelhos recusam; a limpeza própria já foi feita.
        } finally {
            tmp.delete()
        }
        return (before - scan(c).total).coerceAtLeast(0L)
    }
}

class Prefs(private val c: Context) {
    private val sp = c.getSharedPreferences("lc", Context.MODE_PRIVATE)
    var auto: Boolean
        get() = sp.getBoolean("auto", false)
        set(v) = sp.edit().putBoolean("auto", v).apply()
    var hours: Int
        get() = sp.getInt("hours", 6)
        set(v) = sp.edit().putInt("hours", v).apply()

    fun record(bytes: Long) =
        sp.edit().putLong("last_bytes", bytes).putLong("last_time", System.currentTimeMillis()).apply()

    fun lastText(): String {
        val t = sp.getLong("last_time", 0L)
        if (t == 0L) return "Nenhuma limpeza ainda"
        return "Última limpeza: " + DateFormat.format("dd/MM HH:mm", t) + " — " +
            Formatter.formatFileSize(c, sp.getLong("last_bytes", 0L))
    }
}
