package com.lorenzocell.lcleaner

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object CleanState {
    var running by mutableStateOf(false)
    var done by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
}

/** Abre a tela de cada app nas Configurações e toca em "Limpar cache". */
class CleanerService : AccessibilityService() {
    companion object {
        var instance: CleanerService? = null
        fun start(pkgs: List<String>): Boolean {
            val s = instance ?: return false
            if (pkgs.isEmpty()) return false
            s.begin(pkgs); return true
        }
        fun stop() { instance?.stopAll() }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var cleared = false
    private var busy = false

    private val clearTexts = listOf("Clear cache", "Limpar cache", "Limpar o cache", "Borrar caché", "Vider le cache")
    private val storageTexts = listOf("Storage & cache", "Armazenamento e cache", "Storage", "Armazenamento", "Almacenamiento", "Stockage")

    override fun onServiceConnected() { instance = this }
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null; CleanState.running = false
        return super.onUnbind(intent)
    }

    fun begin(pkgs: List<String>) {
        queue.clear(); queue.addAll(pkgs)
        CleanState.total = pkgs.size; CleanState.done = 0; CleanState.running = true
        next()
    }

    fun stopAll() {
        handler.removeCallbacksAndMessages(null); queue.clear(); CleanState.running = false
    }

    private fun next() {
        handler.removeCallbacksAndMessages(null)
        cleared = false; busy = false
        val p = queue.removeFirstOrNull()
        if (p == null) { finish(); return }
        CleanState.done++
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        handler.postDelayed({ next() }, 9000) // segurança: pula o app se travar
    }

    private fun finish() {
        CleanState.running = false
        packageManager.getLaunchIntentForPackage(packageName)?.let {
            startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!CleanState.running || busy || cleared) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.contains("settings") != true) return
        val clear = find(root, clearTexts)
        if (clear != null) {
            cleared = true
            val enabled = clickable(clear)?.isEnabled == true
            if (enabled) click(clear)
            handler.removeCallbacksAndMessages(null)
            handler.postDelayed({ next() }, if (enabled) 900L else 400L)
            return
        }
        val storage = find(root, storageTexts) ?: return
        busy = true
        click(storage)
        handler.postDelayed({ busy = false }, 700)
    }

    private fun find(root: AccessibilityNodeInfo, texts: List<String>): AccessibilityNodeInfo? {
        for (t in texts) {
            val l = root.findAccessibilityNodeInfosByText(t)
            if (!l.isNullOrEmpty()) return l[0]
        }
        return null
    }

    private fun clickable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x
    }

    private fun click(n: AccessibilityNodeInfo) { clickable(n)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
}
