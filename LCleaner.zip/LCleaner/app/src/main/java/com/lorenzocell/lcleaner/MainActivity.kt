package com.lorenzocell.lcleaner

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Green = Color(0xFF2BFF3F)
private val Lime = Color(0xFF8DFF3A)
private val Mute = Color(0xFF7FA385)
private val CardBg = Color(0xCC0A140C)

private var resumeTick by mutableIntStateOf(0)

private fun a11yEnabled(c: Context): Boolean {
    val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(c.packageName + "/")
}

class MainActivity : ComponentActivity() {
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(ctx) }
    var scan by remember { mutableStateOf<Cleaner.Scan?>(null) }
    var busy by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Analisando…") }
    var auto by remember { mutableStateOf(prefs.auto) }
    var hours by remember { mutableIntStateOf(prefs.hours) }
    var last by remember { mutableStateOf(prefs.lastText()) }
    val a11yOn = remember(resumeTick) { a11yEnabled(ctx) }

    suspend fun refresh() {
        busy = true; status = "Analisando…"
        scan = withContext(Dispatchers.IO) { Cleaner.scan(ctx) }
        busy = false; status = "prontos para limpar"
    }
    LaunchedEffect(Unit) { refresh() }

    val rot by rememberInfiniteTransition(label = "rot").animateFloat(
        0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "rot"
    )
    val frac = ((scan?.total ?: 0L).toFloat() / (2L * 1024 * 1024 * 1024)).coerceIn(0.04f, 1f)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(R.drawable.bg_lorenzo), null, Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop, alpha = 0.3f)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo_lcleaner), "Logo L Cleaner",
                    Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("L Cleaner", color = Color.White, fontSize = 26.sp,
                        fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                    Text("Limpeza de cache inteligente", color = Mute, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(28.dp))
            Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 22f
                    val tl = Offset(sw / 2, sw / 2)
                    val sz = Size(size.width - sw, size.height - sw)
                    drawArc(Color(0xFF16301B), 0f, 360f, false, tl, sz, style = Stroke(sw))
                    if (busy) drawArc(Green, rot, 90f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    else drawArc(Brush.linearGradient(listOf(Green, Lime)), -90f, 360f * frac, false,
                        tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (scan == null) "—" else Formatter.formatFileSize(ctx, scan!!.total),
                        color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic)
                    Text(status, color = Mute, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(28.dp))
            Button(
                onClick = {
                    scope.launch {
                        busy = true; status = "Limpando…"
                        val freed = withContext(Dispatchers.IO) { Cleaner.clean(ctx) }
                        prefs.record(freed); last = prefs.lastText()
                        refresh()
                        status = Formatter.formatFileSize(ctx, freed) + " liberados"
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
            ) { Text("LIMPEZA RÁPIDA", fontSize = 20.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic) }

            Spacer(Modifier.height(16.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardBg).padding(16.dp)
            ) {
                Text("Limpeza profunda (todos os apps)", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (!a11yOn) "Ative o serviço de acessibilidade do L Cleaner"
                    else if (CleanState.running) "Limpando ${CleanState.done} de ${CleanState.total}…"
                    else "Abre cada app nas Configurações e toca em Limpar cache",
                    color = Mute, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (!a11yOn) ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        else if (CleanState.running) CleanerService.stop()
                        else {
                            val pkgs = ctx.packageManager
                                .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                                .map { it.activityInfo.packageName }.distinct().filter { it != ctx.packageName }
                            if (!CleanerService.start(pkgs))
                                Toast.makeText(ctx, "Ative o serviço do L Cleaner primeiro", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                ) {
                    Text(
                        if (!a11yOn) "ATIVAR SERVIÇO" else if (CleanState.running) "PARAR" else "LIMPAR TODOS OS APPS",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardBg).padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Auto limpeza", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (auto) "Ativa — a cada $hours h" else "Desativada", color = Mute, fontSize = 14.sp)
                    }
                    Switch(checked = auto, onCheckedChange = {
                        auto = it; prefs.auto = it
                        if (it) Auto.enable(ctx, hours) else Auto.disable(ctx)
                    }, colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.Black))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 6, 24).forEach { h ->
                        FilterChip(selected = hours == h, onClick = {
                            hours = h; prefs.hours = h
                            if (auto) Auto.enable(ctx, h)
                        }, label = { Text(if (h == 24) "Todo dia" else "$h h") })
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(last, color = Mute, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Text("O Android não deixa um app apagar o cache de outros diretamente. O L Cleaner limpa o próprio " +
                "cache e pede ao sistema para liberar espaço; o resultado varia por aparelho.",
                color = Mute, fontSize = 12.sp)
        }
    }
}
