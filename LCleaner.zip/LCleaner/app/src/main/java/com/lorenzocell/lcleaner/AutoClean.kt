package com.lorenzocell.lcleaner

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

class AutoCleanWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        val freed = Cleaner.clean(applicationContext)
        Prefs(applicationContext).record(freed)
        return Result.success()
    }
}

object Auto {
    private const val NAME = "lc_auto"
    fun enable(c: Context, hours: Int) {
        val req = PeriodicWorkRequestBuilder<AutoCleanWorker>(hours.toLong(), TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
    fun disable(c: Context) { WorkManager.getInstance(c).cancelUniqueWork(NAME) }
}
