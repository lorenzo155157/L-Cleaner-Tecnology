# L Cleaner (Android)
1. Instale o Android Studio (versão recente) e use File > Open nesta pasta.
2. Aguarde o Gradle sincronizar (precisa de internet na primeira vez).
3. Conecte o celular (depuração USB) e clique em Run.
Para gerar o APK: Build > Build APK(s).
